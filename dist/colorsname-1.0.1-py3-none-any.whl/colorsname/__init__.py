'''
`colorsname`
'''

from colorsname._colorsname import colorsname

print('import',__name__,'succ')
